package baseball;
import java.util.Scanner;
public class Main {
	//These five stats are all calculated using the following inputs:

					
		
	public static void main(String[] args) { //user input beginning in java , yay for google 
		
		Scanner doit = new Scanner(System.in);
				//crap ton of assignments based on user input
				System.out.println("Player's Name?");
				
				String PlayerName = doit.nextLine();
					
				System.out.println("Number of hits? ");
				
				int H = doit.nextInt();
				
				System.out.println("Number of at bats?");
				
				int AB = doit.nextInt();

				System.out.println("Number of doubles?");
				
				int dbl = doit.nextInt();
				
				System.out.println("Number of triples?");
				
				int triple = doit.nextInt();
				
				System.out.println("Number of home runs?");
				
				int HR = doit.nextInt();
				
				System.out.println("total runs?");
				
				int R = doit.nextInt();
				
				System.out.println("Number of walks?");
				
				int BB = doit.nextInt();
				
				
				baseballstats player = new baseballstats(PlayerName, H, AB, BB, R, dbl, triple, HR);
				// this is how to call methods from another class^^^ .. thanks again google lol
				
				
				System.out.println("Stats of " + PlayerName + ".");
				System.out.println("Batting Average: " + player.BattingAverage());
				
				System.out.println("On Base Percentage: " + player.OnBasePercentage());
				
			    System.out.println("Slugging Percentage: " + player.SluggingPercentage());
				
				System.out.println("OBS:  " + player.OBS());
				
				System.out.println("Total Bases: " + player.TotalBases());
			
				//the above call the class/methods from baseballstats using the assignment player
		}}








