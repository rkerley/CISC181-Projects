package baseball;

public class baseballstats {

	//These five stats are all calculated using the following inputs:

	int AB; //- At bats

	int H ;//- Hits

	int dbl; //- doubles

	int triple; //- triples

	int HR ;//- Home Runs

	int R ;//- Runs

	int BB ;//- Walks

	private String PlayerName;
	

	public baseballstats(String PlayerName, int aB, int bB, int dbl,
			int triple, int hR, int H, int R) {
		//without this, i cannot allow the methods to work correctly in the main .java file
		
		this.PlayerName = PlayerName;
		
		
		AB = aB;
		BB = bB;
		
		this.R = R;
		this.dbl = dbl;
		this.triple = triple;
		HR = hR;
	}
	public double BattingAverage(){
		return Double.valueOf(H) / Double.valueOf(AB);
		
	}

	public double OnBasePercentage() {
		return  Double.valueOf(H + BB )/Double.valueOf(AB + BB);
		
	}
	
	public double TotalBases() {
		return  (1*Singles()) + (2*dbl) + (3*triple) + (4*HR);
	}
	
	public double SluggingPercentage() {
		return  TotalBases()/AB;
		
	}
	
	public double OBS() {
		return  OnBasePercentage() + SluggingPercentage();
		
	}
	
	
	public double Singles() {
		return  H - (dbl + triple + HR);
			}
	
	//the above are the methods needed to calculate the 5 stats needed to be displayed as well as 
	// a singles method to find the number of singles mathematically instead of the user inputting the number themselves
	}